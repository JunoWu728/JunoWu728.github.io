
# coding: utf-8

# In[17]:



#!/usr/bin/env python

import os
import aop
import aop.api
import pandas as pd
from pandas.io.json import json_normalize
import time
import json
import urllib
from datetime import date, timedelta

android_key = '5a9e31a1b27b0a6f070000f9'
ios_key = '5a9e15a2b27b0a414d00017f'

startDate = '2018-03-01'
endDate = time.strftime("%Y-%m-%d")

# 设置网关域名
aop.set_default_server('gateway.open.umeng.com')
# 设置apiKey和apiSecurity
aop.set_default_appinfo(4769394, "qiI4dM8gSUx")


# In[18]:


####1.TLC Top 10 games of week#### 
req = aop.api.UmengUappEventParamGetValueListRequest()

LastMonday = date.today() - timedelta(7)
LastSunday = date.today() - timedelta(1)

#date_list = ['2018-09-30','2018-10-01','2018-10-02','2018-10-02','2018-10-03','2018-10-04','2018-10-05','2018-10-06','2018-10-07','2018-10-08','2018-10-09','2018-10-10']
date_list = pd.date_range(start=LastMonday.strftime("%Y-%m-%d"), end=LastSunday.strftime("%Y-%m-%d")).date
#date_list = ['2018-10-09','2018-10-10']


tmp2 = pd.DataFrame(columns=['count','date','event_name','event_value_name'])
#tmp2 = pd.read_csv('/media/sf_data/Umeng_event_/Umeng_event_value_data_android_tmp.csv')

#for j in event_name.name :
for j in ['Game_Launch'] :
    print j
    for i in date_list :
        try:
            resp = req.get_response(None, appkey=android_key, startDate=i, endDate=i, eventName=j, eventParamName=j)
        except aop.ApiError as e:
            time.sleep(10)
            resp = req.get_response(None, appkey=android_key, startDate=i, endDate=i, eventName=j, eventParamName=j)
        except aop.AopError as e:
            time.sleep(10)
            resp = req.get_response(None, appkey=android_key, startDate=i, endDate=i, eventName=j, eventParamName=j)
        except Exception as e:
            time.sleep(10)
            resp = req.get_response(None, appkey=android_key, startDate=i, endDate=i, eventName=j, eventParamName=j)

        tmp1 = json_normalize(resp['paramInfos'])
        
        if tmp1.shape[0] == 0:
            time.sleep(2)
            print i
            continue
        
        tmp1['date'] = i
        tmp1['event_name'] = j
        tmp2 = tmp2.append(tmp1)
        time.sleep(2)
        print i


# In[19]:


tmp3 = pd.DataFrame(columns=['count','date','event_name','event_value_name'])
#tmp2 = pd.read_csv('/media/sf_data/Umeng_event_/Umeng_event_value_data_android_tmp.csv')

#for j in event_name.name :
for j in ['GameLaunch'] :
    print j
    for i in date_list :
        try:
            resp = req.get_response(None, appkey=ios_key, startDate=i, endDate=i, eventName=j, eventParamName=j)
        except aop.ApiError as e:
            time.sleep(10)
            resp = req.get_response(None, appkey=ios_key, startDate=i, endDate=i, eventName=j, eventParamName=j)
        except aop.AopError as e:
            time.sleep(10)
            resp = req.get_response(None, appkey=ios_key, startDate=i, endDate=i, eventName=j, eventParamName=j)
        except Exception as e:
            time.sleep(10)
            resp = req.get_response(None, appkey=ios_key, startDate=i, endDate=i, eventName=j, eventParamName=j)

        tmp1 = json_normalize(resp['paramInfos'])
        
        if tmp1.shape[0] == 0:
            time.sleep(2)
            print i
            continue
        
        tmp1['date'] = i
        tmp1['event_name'] = j
        tmp3 = tmp3.append(tmp1)
        time.sleep(2)
        print i


# In[20]:


tmp2['device'] = 'android'
tmp3['device'] = 'ios'

tmp2 = tmp2.append(tmp3)

#change to urf-8
tmp2['new_event_value_name'] = ""
for i in range(len(tmp2)):
    tmp2['new_event_value_name'].values[i] = urllib.unquote(urllib.unquote(str(tmp2['name'].values[i])))

tmp2.rename(columns={'name': 'event_value_name'}, inplace=True)

tmp2.to_csv('/media/sf_data/Umeng_event_/weekly/1-top10.csv', encoding='utf-8', index=False)


# In[21]:


####2.TLC New user weekly retention#### 

LastLastMonday = date.today() - timedelta(14+(7*17))
LastSunday = date.today() 

# 构造Request和访问协议是否是https
req = aop.api.UmengUappGetRetentionsRequest()

# 发起Api请求
try:
    resp = req.get_response(None, appkey=android_key, startDate=LastLastMonday, endDate=LastSunday, periodType="weekly", channel="", version="")
    print(resp)
except aop.ApiError as e:
    # Api网关返回的异常
    print(e)
except aop.AopError as e:
    # 客户端Api网关请求前的异常
    print(e)
except Exception as e:
    # 其它未知异常
    print(e)


# In[22]:


newAccount = json_normalize(resp['retentionInfo'])
newAccount['device'] = 'android'


# In[23]:


# 构造Request和访问协议是否是https
req = aop.api.UmengUappGetRetentionsRequest()

# 发起Api请求
try:
    resp = req.get_response(None, appkey=ios_key, startDate=LastLastMonday, endDate=LastSunday, periodType="weekly", channel="", version="")
    print(resp)
except aop.ApiError as e:
    # Api网关返回的异常
    print(e)
except aop.AopError as e:
    # 客户端Api网关请求前的异常
    print(e)
except Exception as e:
    # 其它未知异常
    print(e)


# In[24]:


newAccount1 = json_normalize(resp['retentionInfo'])
newAccount1['device'] = 'ios'
#merge
newAccount1 = newAccount1.append(newAccount)
newAccount1.to_csv('/media/sf_data/Umeng_event_/weekly/2-Newuserweeklyretention.csv', encoding='utf-8', index=False)


# In[25]:


#FUN88
ios_key = '5b0383c48f4a9d06d8000068'
android_key = '5b0384aaf29d98709600007c'


# In[ ]:


####3.FUN88 Top 10 games of week#### 
req = aop.api.UmengUappEventParamGetValueListRequest()

LastMonday = date.today() - timedelta(7)
LastSunday = date.today() - timedelta(1)

#date_list = ['2018-09-30','2018-10-01','2018-10-02','2018-10-02','2018-10-03','2018-10-04','2018-10-05','2018-10-06','2018-10-07','2018-10-08','2018-10-09','2018-10-10']
date_list = pd.date_range(start=LastMonday.strftime("%Y-%m-%d"), end=LastSunday.strftime("%Y-%m-%d")).date
#date_list = ['2018-10-09','2018-10-10']


tmp2 = pd.DataFrame(columns=['count','date','event_name','event_value_name'])
#tmp2 = pd.read_csv('/media/sf_data/Umeng_event_/Umeng_event_value_data_android_tmp.csv')

#for j in event_name.name :
for j in ['game_name'] :
    print j
    for i in date_list :
        try:
            resp = req.get_response(None, appkey=android_key, startDate=i, endDate=i, eventName='c_play_game', eventParamName=j)
        except aop.ApiError as e:
            time.sleep(10)
            resp = req.get_response(None, appkey=android_key, startDate=i, endDate=i, eventName='c_play_game', eventParamName=j)
        except aop.AopError as e:
            time.sleep(10)
            resp = req.get_response(None, appkey=android_key, startDate=i, endDate=i, eventName='c_play_game', eventParamName=j)
        except Exception as e:
            time.sleep(10)
            resp = req.get_response(None, appkey=android_key, startDate=i, endDate=i, eventName='c_play_game', eventParamName=j)

        tmp1 = json_normalize(resp['paramInfos'])
        
        if tmp1.shape[0] == 0:
            time.sleep(2)
            print i
            continue
        
        tmp1['date'] = i
        tmp1['event_name'] = j
        tmp2 = tmp2.append(tmp1)
        time.sleep(2)
        print i


# In[ ]:


tmp3 = pd.DataFrame(columns=['count','date','event_name','event_value_name'])
#tmp2 = pd.read_csv('/media/sf_data/Umeng_event_/Umeng_event_value_data_android_tmp.csv')

#for j in event_name.name :
for j in ['game_name'] :
    print j
    for i in date_list :
        try:
            resp = req.get_response(None, appkey=ios_key, startDate=i, endDate=i, eventName='c_play_game', eventParamName=j)
        except aop.ApiError as e:
            time.sleep(10)
            resp = req.get_response(None, appkey=ios_key, startDate=i, endDate=i, eventName='c_play_game', eventParamName=j)
        except aop.AopError as e:
            time.sleep(10)
            resp = req.get_response(None, appkey=ios_key, startDate=i, endDate=i, eventName='c_play_game', eventParamName=j)
        except Exception as e:
            time.sleep(10)
            resp = req.get_response(None, appkey=ios_key, startDate=i, endDate=i, eventName='c_play_game', eventParamName=j)

        tmp1 = json_normalize(resp['paramInfos'])
        
        if tmp1.shape[0] == 0:
            time.sleep(2)
            print i
            continue
        
        tmp1['date'] = i
        tmp1['event_name'] = j
        tmp3 = tmp3.append(tmp1)
        time.sleep(2)
        print i


# In[ ]:


tmp2['device'] = 'android'
tmp3['device'] = 'ios'

tmp2 = tmp2.append(tmp3)

#change to urf-8
tmp2['new_event_value_name'] = ""
for i in range(len(tmp2)):
    tmp2['new_event_value_name'].values[i] = urllib.unquote(urllib.unquote(str(tmp2['name'].values[i])))

tmp2.rename(columns={'name': 'event_value_name'}, inplace=True)

tmp2.to_csv('/media/sf_data/Umeng_event_/weekly/1-top10_fun88.csv', encoding='utf-8', index=False)


# In[ ]:


####2.TLC New user weekly retention#### 

LastLastMonday = date.today() - timedelta(14+(7*17))
LastSunday = date.today()

# 构造Request和访问协议是否是https
req = aop.api.UmengUappGetRetentionsRequest()

# 发起Api请求
try:
    resp = req.get_response(None, appkey=android_key, startDate=LastLastMonday, endDate=LastSunday, periodType="weekly", channel="", version="")
    print(resp)
except aop.ApiError as e:
    # Api网关返回的异常
    print(e)
except aop.AopError as e:
    # 客户端Api网关请求前的异常
    print(e)
except Exception as e:
    # 其它未知异常
    print(e)


# In[ ]:


newAccount = json_normalize(resp['retentionInfo'])
newAccount['device'] = 'android'


# In[ ]:


# 构造Request和访问协议是否是https
req = aop.api.UmengUappGetRetentionsRequest()

# 发起Api请求
try:
    resp = req.get_response(None, appkey=ios_key, startDate=LastLastMonday, endDate=LastSunday, periodType="weekly", channel="", version="")
    print(resp)
except aop.ApiError as e:
    # Api网关返回的异常
    print(e)
except aop.AopError as e:
    # 客户端Api网关请求前的异常
    print(e)
except Exception as e:
    # 其它未知异常
    print(e)


# In[ ]:


newAccount1 = json_normalize(resp['retentionInfo'])
newAccount1['device'] = 'ios'
#merge
newAccount1 = newAccount1.append(newAccount)
newAccount1.to_csv('/media/sf_data/Umeng_event_/weekly/2-Newuserweeklyretention_fun88.csv', encoding='utf-8', index=False)



# coding: utf-8

# In[22]:



#!/usr/bin/env python

import os
import aop
import aop.api
import pandas as pd
from pandas.io.json import json_normalize
import time
import json
import urllib
from datetime import date, timedelta

android_key = '5a9e31a1b27b0a6f070000f9'
ios_key = '5a9e15a2b27b0a414d00017f'

startDate = '2018-03-01'
endDate = time.strftime("%Y-%m-%d")

# 设置网关域名
aop.set_default_server('gateway.open.umeng.com')
# 设置apiKey和apiSecurity
aop.set_default_appinfo(4769394, "qiI4dM8gSUx")


# In[23]:


####GetNewAccounts####

# 构造Request和访问协议是否是https
req = aop.api.UmengUappGetNewAccountsRequest()

#android
# 发起Api请求
try:
    resp = req.get_response(None, appkey=android_key, startDate=startDate, endDate=endDate, periodType="daily", channel="")
    #print(resp)
except aop.ApiError as e:
    # Api网关返回的异常
    print(e)
except aop.AopError as e:
    # 客户端Api网关请求前的异常
    print(e)
except Exception as e:
    # 其它未知异常
    print(e)


# In[24]:


newAccount = json_normalize(resp['newAccountInfo'])
newAccount['device'] = 'android'


# In[25]:


#ios
# 发起Api请求
try:
    resp = req.get_response(None, appkey=ios_key, startDate=startDate, endDate=endDate, periodType="daily", channel="")
    #print(resp)
except aop.ApiError as e:
    # Api网关返回的异常
    print(e)
except aop.AopError as e:
    # 客户端Api网关请求前的异常
    print(e)
except Exception as e:
    # 其它未知异常
    print(e)    


# In[26]:


newAccount1 = json_normalize(resp['newAccountInfo'])
newAccount1['device'] = 'ios'
#merge
newAccount1 = newAccount1.append(newAccount)


# In[27]:


####getLaunchesByChannelOrVersion####
# 构造Request和访问协议是否是https
req = aop.api.UmengUappGetActiveUsersByChannelOrVersionRequest()

# 发起Api请求
try:
    resp = req.get_response(None, appkey=android_key, startDate=startDate, endDate=endDate, periodType="daily", channels="", versions="")
    print(resp)
except aop.ApiError as e:
    # Api网关返回的异常
    print(e)
except aop.AopError as e:
    # 客户端Api网关请求前的异常
    print(e)
except Exception as e:
    # 其它未知异常
    print(e)


# In[28]:


newAccount2 = json_normalize(resp['activeUserInfo'])
newAccount2['device'] = 'android'


# In[29]:


# 构造Request和访问协议是否是https
req = aop.api.UmengUappGetActiveUsersByChannelOrVersionRequest()

# 发起Api请求
try:
    resp = req.get_response(None, appkey=ios_key, startDate=startDate, endDate=endDate, periodType="daily", channels="", versions="")
    print(resp)
except aop.ApiError as e:
    # Api网关返回的异常
    print(e)
except aop.AopError as e:
    # 客户端Api网关请求前的异常
    print(e)
except Exception as e:
    # 其它未知异常
    print(e)


# In[30]:


newAccount3 = json_normalize(resp['activeUserInfo'])
newAccount3['device'] = 'ios'
#merge
newAccount3 = newAccount3.append(newAccount2)


# In[31]:


result = pd.merge(newAccount1, newAccount3, how='left', on=['date', 'device'])
result.rename(columns={'newUser': 'New Installations', 'value': 'Active Users of day'}, inplace=True)
result = result[['date','device','New Installations','Active Users of day']]

result.to_csv('/media/sf_data/Umeng_event_/Native App Daily Statistics.csv', encoding='utf-8', index=False)


# In[32]:


#####GetWeeklyAccounts####
req = aop.api.UmengUappGetActiveAccountsRequest()

resp = req.get_response(None, appkey=android_key, startDate=startDate, endDate=endDate, periodType="weekly", channels="", versions="")
newAccount = json_normalize(resp['activeAccountInfo'])

newAccount['device'] = 'android'
newAccount['DateEnd'] = pd.to_datetime(newAccount.date) + timedelta(6)

resp = req.get_response(None, appkey=ios_key, startDate=startDate, endDate=endDate, periodType="weekly", channels="", versions="")
newAccount1 = json_normalize(resp['activeAccountInfo'])

newAccount1['device'] = 'ios'
newAccount1['DateEnd'] = pd.to_datetime(newAccount1.date) + timedelta(6)

newAccount1 = newAccount1.append(newAccount)
newAccount1.rename(columns={'DateStart': 'date'}, inplace=True)

newAccount1.to_csv('/media/sf_data/Umeng_event_/Native App Weekly Statistics.csv', encoding='utf-8', index=False)


# In[33]:


#####GetMonthlyAccounts####
req = aop.api.UmengUappGetActiveAccountsRequest()

resp = req.get_response(None, appkey=android_key, startDate=startDate, endDate=endDate, periodType="monthly", channels="", versions="")
newAccount = json_normalize(resp['activeAccountInfo'])

newAccount['device'] = 'android'

resp = req.get_response(None, appkey=ios_key, startDate=startDate, endDate=endDate, periodType="monthly", channels="", versions="")
newAccount1 = json_normalize(resp['activeAccountInfo'])

newAccount1['device'] = 'ios'

newAccount1 = newAccount1.append(newAccount)

newAccount1.to_csv('/media/sf_data/Umeng_event_/Native App Monthly Statistics.csv', encoding='utf-8', index=False)


# In[40]:


####Fun88####

ios_key = '5b0383c48f4a9d06d8000068'
android_key = '5b0384aaf29d98709600007c'


# In[41]:


####GetNewAccounts####

# 构造Request和访问协议是否是https
req = aop.api.UmengUappGetNewAccountsRequest()

#android
# 发起Api请求
try:
    resp = req.get_response(None, appkey=android_key, startDate=startDate, endDate=endDate, periodType="daily", channel="")
    #print(resp)
except aop.ApiError as e:
    # Api网关返回的异常
    print(e)
except aop.AopError as e:
    # 客户端Api网关请求前的异常
    print(e)
except Exception as e:
    # 其它未知异常
    print(e)


# In[42]:


newAccount = json_normalize(resp['newAccountInfo'])
newAccount['device'] = 'android'


# In[43]:


#ios
# 发起Api请求
try:
    resp = req.get_response(None, appkey=ios_key, startDate=startDate, endDate=endDate, periodType="daily", channel="")
    #print(resp)
except aop.ApiError as e:
    # Api网关返回的异常
    print(e)
except aop.AopError as e:
    # 客户端Api网关请求前的异常
    print(e)
except Exception as e:
    # 其它未知异常
    print(e)    


# In[44]:


newAccount1 = json_normalize(resp['newAccountInfo'])
newAccount1['device'] = 'ios'
#merge
newAccount1 = newAccount1.append(newAccount)


# In[47]:


####getLaunchesByChannelOrVersion####
# 构造Request和访问协议是否是https
req = aop.api.UmengUappGetActiveUsersByChannelOrVersionRequest()

# 发起Api请求
try:
    resp = req.get_response(None, appkey=android_key, startDate=startDate, endDate=endDate, periodType="daily", channels="", versions="")
    print(resp)
except aop.ApiError as e:
    print(e)
except aop.AopError as e:
    print(e)
except Exception as e:
    print(e)


# In[48]:


newAccount2 = json_normalize(resp['activeUserInfo'])
newAccount2['device'] = 'android'


# In[49]:


# 构造Request和访问协议是否是https
req = aop.api.UmengUappGetActiveUsersByChannelOrVersionRequest()

# 发起Api请求
try:
    resp = req.get_response(None, appkey=ios_key, startDate=startDate, endDate=endDate, periodType="daily", channels="", versions="")
    print(resp)
except aop.ApiError as e:
    # Api网关返回的异常
    print(e)
except aop.AopError as e:
    # 客户端Api网关请求前的异常
    print(e)
except Exception as e:
    # 其它未知异常
    print(e)


# In[50]:


newAccount3 = json_normalize(resp['activeUserInfo'])
newAccount3['device'] = 'ios'
#merge
newAccount3 = newAccount3.append(newAccount2)


# In[51]:


result = pd.merge(newAccount1, newAccount3, how='left', on=['date', 'device'])
result.rename(columns={'newUser': 'New Installations', 'value': 'Active Users of day'}, inplace=True)
result = result[['date','device','New Installations','Active Users of day']]

result.to_csv('/media/sf_data/Umeng_event_/Native App Daily Statistics_FUN88.csv', encoding='utf-8', index=False)


# In[52]:


#####GetWeeklyAccounts####
req = aop.api.UmengUappGetActiveAccountsRequest()

resp = req.get_response(None, appkey=android_key, startDate=startDate, endDate=endDate, periodType="weekly", channels="", versions="")
newAccount = json_normalize(resp['activeAccountInfo'])

newAccount['device'] = 'android'
newAccount['DateEnd'] = pd.to_datetime(newAccount.date) + timedelta(6)

resp = req.get_response(None, appkey=ios_key, startDate=startDate, endDate=endDate, periodType="weekly", channels="", versions="")
newAccount1 = json_normalize(resp['activeAccountInfo'])

newAccount1['device'] = 'ios'
newAccount1['DateEnd'] = pd.to_datetime(newAccount1.date) + timedelta(6)

newAccount1 = newAccount1.append(newAccount)
newAccount1.rename(columns={'DateStart': 'date'}, inplace=True)

newAccount1.to_csv('/media/sf_data/Umeng_event_/Native App Weekly Statistics_FUN88.csv', encoding='utf-8', index=False)


# In[53]:


#####GetMonthlyAccounts####
req = aop.api.UmengUappGetActiveAccountsRequest()

resp = req.get_response(None, appkey=android_key, startDate=startDate, endDate=endDate, periodType="monthly", channels="", versions="")
newAccount = json_normalize(resp['activeAccountInfo'])

newAccount['device'] = 'android'

resp = req.get_response(None, appkey=ios_key, startDate=startDate, endDate=endDate, periodType="monthly", channels="", versions="")
newAccount1 = json_normalize(resp['activeAccountInfo'])

newAccount1['device'] = 'ios'

newAccount1 = newAccount1.append(newAccount)

newAccount1.to_csv('/media/sf_data/Umeng_event_/Native App Monthly Statistics_FUN88.csv', encoding='utf-8', index=False)


# In[54]:


####RB88####
android_key = '5bfe522bb465f5ab48000152'
ios_key = '5bfe527af1f5565c2b000054'

startDate = '2019-01-23'
endDate = time.strftime("%Y-%m-%d")

# 设置网关域名
aop.set_default_server('gateway.open.umeng.com')
# 设置apiKey和apiSecurity
aop.set_default_appinfo(4769394, "qiI4dM8gSUx")


# In[55]:


####GetNewAccounts####

req = aop.api.UmengUappGetNewAccountsRequest()

#android
try:
    resp = req.get_response(None, appkey=android_key, startDate=startDate, endDate=endDate, periodType="daily", channel="")
except aop.ApiError as e:
    print(e)
except aop.AopError as e:
    print(e)
except Exception as e:
    print(e)

newAccount = json_normalize(resp['newAccountInfo'])
newAccount['device'] = 'android'

#ios
# 发起Api请求
try:
    resp = req.get_response(None, appkey=ios_key, startDate=startDate, endDate=endDate, periodType="daily", channel="")
#print(resp)
except aop.ApiError as e:
    print(e)
except aop.AopError as e:
    print(e)
except Exception as e:
    print(e)    

newAccount1 = json_normalize(resp['newAccountInfo'])
newAccount1['device'] = 'ios'
#merge
newAccount1 = newAccount1.append(newAccount)


# In[56]:


####getLaunchesByChannelOrVersion####
# 构造Request和访问协议是否是https
req = aop.api.UmengUappGetActiveUsersByChannelOrVersionRequest()

# 发起Api请求
try:
    resp = req.get_response(None, appkey=android_key, startDate=startDate, endDate=endDate, periodType="daily", channels="", versions="")
    print(resp)
except aop.ApiError as e:
    # Api网关返回的异常
    print(e)
except aop.AopError as e:
    # 客户端Api网关请求前的异常
    print(e)
except Exception as e:
    # 其它未知异常
    print(e)

newAccount2 = json_normalize(resp['activeUserInfo'])
newAccount2['device'] = 'android'

# 构造Request和访问协议是否是https
req = aop.api.UmengUappGetActiveUsersByChannelOrVersionRequest()

# 发起Api请求
try:
    resp = req.get_response(None, appkey=ios_key, startDate=startDate, endDate=endDate, periodType="daily", channels="", versions="")
    print(resp)
except aop.ApiError as e:
    # Api网关返回的异常
    print(e)
except aop.AopError as e:
    # 客户端Api网关请求前的异常
    print(e)
except Exception as e:
    # 其它未知异常
    print(e)
    
newAccount3 = json_normalize(resp['activeUserInfo'])
newAccount3['device'] = 'ios'
#merge
newAccount3 = newAccount3.append(newAccount2)


# In[57]:


result = pd.merge(newAccount1, newAccount3, how='left', on=['date', 'device'])
result.rename(columns={'newUser': 'New Installations', 'value': 'Active Users of day'}, inplace=True)
result = result[['date','device','New Installations','Active Users of day']]

result.to_csv('/media/sf_data/Umeng_event_/Native App Daily Statistics_RB88.csv', encoding='utf-8', index=False)


# In[58]:


#####GetWeeklyAccounts####
req = aop.api.UmengUappGetActiveAccountsRequest()

resp = req.get_response(None, appkey=android_key, startDate=startDate, endDate=endDate, periodType="weekly", channels="", versions="")
newAccount = json_normalize(resp['activeAccountInfo'])

newAccount['device'] = 'android'
newAccount['DateEnd'] = pd.to_datetime(newAccount.date) + timedelta(6)

resp = req.get_response(None, appkey=ios_key, startDate=startDate, endDate=endDate, periodType="weekly", channels="", versions="")
newAccount1 = json_normalize(resp['activeAccountInfo'])

newAccount1['device'] = 'ios'
newAccount1['DateEnd'] = pd.to_datetime(newAccount1.date) + timedelta(6)

newAccount1 = newAccount1.append(newAccount)
newAccount1.rename(columns={'DateStart': 'date'}, inplace=True)

newAccount1.to_csv('/media/sf_data/Umeng_event_/Native App Weekly Statistics_RB88.csv', encoding='utf-8', index=False)


# In[59]:


#####GetMonthlyAccounts####
req = aop.api.UmengUappGetActiveAccountsRequest()

resp = req.get_response(None, appkey=android_key, startDate=startDate, endDate=endDate, periodType="monthly", channels="", versions="")
newAccount = json_normalize(resp['activeAccountInfo'])

newAccount['device'] = 'android'

resp = req.get_response(None, appkey=ios_key, startDate=startDate, endDate=endDate, periodType="monthly", channels="", versions="")
newAccount1 = json_normalize(resp['activeAccountInfo'])

newAccount1['device'] = 'ios'

newAccount1 = newAccount1.append(newAccount)

newAccount1.to_csv('/media/sf_data/Umeng_event_/Native App Monthly Statistics_RB88.csv', encoding='utf-8', index=False)


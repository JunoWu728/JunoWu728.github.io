# -*- coding: utf-8 -*-
#!/usr/bin/env python

"""
Created on 2016-12-26

@author: Alibaba Open Platform

"""

# from aop.api.common.AuthGetTokenRequest import AuthGetTokenRequest
# from aop.api.common.AuthPostponeTokenRequest import AuthPostponeTokenRequest
from aop.api.common.GetServerTimestampRequest import GetServerTimestampRequest

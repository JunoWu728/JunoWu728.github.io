# -*- coding: utf-8 -*-
#!/usr/bin/env python

"""
Created on 2016-12-26

@author: Alibaba Open Platform

"""

from aop.api.base import FileItem, BaseApi
from aop.api.common import *
from aop.api.biz import *
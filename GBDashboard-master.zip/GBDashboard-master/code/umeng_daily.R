rm(list=ls(all=TRUE))

library(readr)
library(dplyr)
library(rsconnect)
library(RMySQL)
####daily job####

file.copy('/media/sf_data/Umeng_event_/Native App Daily Statistics.csv','/media/sf_data/code/ShinyAPP_daily/Native App Daily Statistics.csv',overwrite = T)
file.copy('/media/sf_data/Umeng_event_/Native App Daily Statistics_FUN88.csv','/media/sf_data/code/ShinyAPP_daily/Native App Daily Statistics_FUN88.csv',overwrite = T)
file.copy('/media/sf_data/Umeng_event_/Native App Daily Statistics_RB88.csv','/media/sf_data/code/ShinyAPP_daily/Native App Daily Statistics_RB88.csv',overwrite = T)

file.copy('/media/sf_data/Umeng_event_/Native App Monthly Statistics.csv','/media/sf_data/code/ShinyAPP_daily/Native App Monthly Statistics.csv',overwrite = T)
file.copy('/media/sf_data/Umeng_event_/Native App Monthly Statistics_FUN88.csv','/media/sf_data/code/ShinyAPP_daily/Native App Monthly Statistics_FUN88.csv',overwrite = T)
file.copy('/media/sf_data/Umeng_event_/Native App Monthly Statistics_RB88.csv','/media/sf_data/code/ShinyAPP_daily/Native App Monthly Statistics_RB88.csv',overwrite = T)

file.copy('/media/sf_data/Umeng_event_/Native App Weekly Statistics.csv','/media/sf_data/code/ShinyAPP_daily/Native App Weekly Statistics.csv',overwrite = T)
file.copy('/media/sf_data/Umeng_event_/Native App Weekly Statistics_FUN88.csv','/media/sf_data/code/ShinyAPP_daily/Native App Weekly Statistics_FUN88.csv',overwrite = T)
file.copy('/media/sf_data/Umeng_event_/Native App Weekly Statistics_RB88.csv','/media/sf_data/code/ShinyAPP_daily/Native App Weekly Statistics_RB88.csv',overwrite = T)

####weekly job####
#Game_Lanch,GameLanch
tmp <- read_csv('/media/sf_data/Umeng_event_/weekly/1-top10.csv')
tmp1 <- tmp[grepl('_',tmp$new_event_value_name),]
tmp1$new_event_value_name <- sapply(strsplit(as.character(tmp1$new_event_value_name), "_"), "[[", 2)
tmp1 <- tmp1 %>%
  group_by(date,event_name,device,new_event_value_name) %>%
  summarise(count = sum(count))

write_csv(tmp1,'/media/sf_data/code/ShinyAPP_daily/1-top10.csv')

file.copy('/media/sf_data/Umeng_event_/weekly/2-Newuserweeklyretention.csv','/media/sf_data/code/ShinyAPP_daily/2-Newuserweeklyretention.csv',overwrite = T)
file.copy('/media/sf_data/Umeng_event_/weekly/1-top10_fun88.csv','/media/sf_data/code/ShinyAPP_daily/1-top10_fun88.csv',overwrite = T)
file.copy('/media/sf_data/Umeng_event_/weekly/2-Newuserweeklyretention_fun88.csv','/media/sf_data/code/ShinyAPP_daily/2-Newuserweeklyretention_fun88.csv',overwrite = T)
#crash
file.copy('/media/sf_data/Umeng_event_/MetaData/crash.csv','/media/sf_data/code/ShinyAPP_daily/crash.csv',overwrite = T)

####sql####
#root,asdf@12345
#Jeffery,Jeffery@12345
#Tim,Tim@12345
#PhpMyAdmin,Jeff@12345

mydb = dbConnect(MySQL(), user='Jeffery', password='Jeffery@12345', dbname='umeng', host='35.188.162.43', port=3306)

a <- read_csv('/media/sf_data/Umeng_event_/Native App Daily Statistics.csv') 
b <- read_csv('/media/sf_data/Umeng_event_/Native App Daily Statistics_FUN88.csv')
c <- read_csv('/media/sf_data/Umeng_event_/MetaData/crash.csv')

dbWriteTable(mydb, "daily_TLC", a, overwrite=TRUE)
dbWriteTable(mydb, "daily_FUN88", b, overwrite=TRUE)
dbWriteTable(mydb, "crash", c, overwrite=TRUE)


a$year <- sapply(strsplit(as.character(a$date), "-"), "[[", 1)
a$month <- sapply(strsplit(as.character(a$date), "-"), "[[", 2)
a$day <- sapply(strsplit(as.character(a$date), "-"), "[[", 3)

b$year <- sapply(strsplit(as.character(b$date), "-"), "[[", 1)
b$month <- sapply(strsplit(as.character(b$date), "-"), "[[", 2)
b$day <- sapply(strsplit(as.character(b$date), "-"), "[[", 3)

c$year <- sapply(strsplit(as.character(c$date), "-"), "[[", 1)
c$month <- sapply(strsplit(as.character(c$date), "-"), "[[", 2)
c$day <- sapply(strsplit(as.character(c$date), "-"), "[[", 3)

c1 <- c[grepl('TLC',c$device),]
c2 <- c[grepl('FUN88',c$device),]

dbWriteTable(mydb, "daily_TLC_Tim", a, overwrite=TRUE)
dbWriteTable(mydb, "daily_FUN88_Tim", b, overwrite=TRUE)
dbWriteTable(mydb, "crash_TLC_Tim", c1, overwrite=TRUE)
dbWriteTable(mydb, "crash_FUN88_Tim", c2, overwrite=TRUE)

dbDisconnect(mydb)

####deploy####
deployApp('/media/sf_data/code/ShinyAPP_daily', upload = TRUE,launch.browser = FALSE,forceUpdate=TRUE)

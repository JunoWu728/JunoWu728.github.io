rm(list=ls(all=TRUE))

library(RCurl)
library(jsonlite)
library(magrittr)
library(readr)
library(stringr)
library(xlsx)
library(plotly)
library(wesanderson)

#UmengID: linsutim@gmail.com
#UmengPW: GB2Bc12#$

Cookies<- 'UM_distinctid=166bd9968772e0-00a0165016d1f2-b79183d-1fa400-166bd99687843f; cna=FVtdFNCMqFECAXNU7j7wuAo2; um_lang=zh; cn_1260769985_dplus=1%5B%7B%7D%2C0%2C1543571796%2C0%2C1543571796%2Cnull%2C%22166bd9968772e0-00a0165016d1f2-b79183d-1fa400-166bd99687843f%22%2Cnull%2Cnull%2Cnull%5D; l=aBWr6NlYyHauNULmCMaTellBa7074SZPuwgy1Mak2TEhNn6P7RXy1i-o-VwW7_qC55Ty_7-5F; umplus_uc_loginid=linsutim%40gmail.com; uc_session_id=16a034bc-6470-48a6-ba6a-cbdbd62914cb; frame=; CNZZDATA1259864772=853165024-1542940090-https%253A%252F%252Faccount.umeng.com%252F%7C1552369818; cn_1258498910_dplus=1%5B%7B%22userid%22%3A%22linsutim%40gmail.com%22%7D%2C0%2C1552372247%2C0%2C1552372247%2C%22www.google.com%22%2C%22166bd9968772e0-00a0165016d1f2-b79183d-1fa400-166bd99687843f%22%2C%221540779140%22%2C%22https%3A%2F%2Fwww.google.com.ph%2F%22%2C%22www.google.com.ph%22%5D; umplus_uc_token=1StlEAXD5TaCTnUg_og6llg_5d2a3cd2b79843cab4be9f89352bd551; isg=BEREMKwzxLCIZnetYjx9HrJNFcL29XYZByWxYl7l-4_SieRThmnpVikgzWn0kaAf; ummo_ss=BAh7CEkiGXdhcmRlbi51c2VyLnVzZXIua2V5BjoGRVRbCEkiCVVzZXIGOwBGWwZvOhNCU09OOjpPYmplY3RJZAY6CkBkYXRhWxFpX2kjaTBpAaZpAfRpQ2lNaXxpAbtpAGkAaQGqSSIZWWVGYkxBWW1HU3B0Rm5pZ3AxR1kGOwBUSSIUdW1wbHVzX3VjX3Rva2VuBjsARiI9MVN0bEVBWEQ1VGFDVG5VZ19vZzZsbGdfNWQyYTNjZDJiNzk4NDNjYWI0YmU5Zjg5MzUyYmQ1NTFJIg9zZXNzaW9uX2lkBjsAVEkiJTlhNDEyYWZiMjYwMzI1YTVlZTIzMjNjODRkYTJkYzYyBjsARg%3D%3D--d95e96eea12412855e9c7a0dc19bfba8132963fd; cn_1273967994_dplus=1%5B%7B%7D%2Cnull%2Cnull%2Cnull%2Cnull%2C%22%24direct%22%2C%22166bd9968772e0-00a0165016d1f2-b79183d-1fa400-166bd99687843f%22%2C%221545889117%22%2C%22https%3A%2F%2Fmobile.umeng.com%2Fapps%3Fframe%3D0%22%2C%22mobile.umeng.com%22%5D; cn_1259864772_dplus=1%5B%7B%22UserID%22%3A%22linsutim%40gmail.com%22%2C%22Uapp_appkey%22%3A%225b0383c48f4a9d06d8000068%22%2C%22%E6%98%AF%E5%90%A6%E7%99%BB%E5%BD%95%22%3Atrue%2C%22Uapp_platform%22%3A%22iphone%22%7D%2C0%2C1552272009%2C0%2C1552272009%2C%22%24direct%22%2C%22166bd9968772e0-00a0165016d1f2-b79183d-1fa400-166bd99687843f%22%2C%221544584931%22%2C%22https%3A%2F%2Fmobile.umeng.com%2Fapps%2F371000bda6655f1ffd15efb5%2Fgame_reports%2Frealtime_summary%22%2C%22mobile.umeng.com%22%5D; JSESSIONID=BFB3377B1591EED6696E7849F9BE1BEF'

device_list <- c('5a9e31a1b27b0a6f070000f9','5a9e15a2b27b0a414d00017f','5b0383c48f4a9d06d8000068')
device_name <- c('TLC_android','TLC_ios','FUN88_ios')
start_date <- gsub('-','',as.character(Sys.Date()-15))
end_date <- gsub('-','',as.character(Sys.Date()-1))

all <- read_csv('/media/sf_data/Umeng_event_/MetaData/crash.csv') %>%
  filter(date < max(date))

date_list <- as.character(unique(all$date))

for (i in 1:length(device_list)) {
  url <- paste0("https://mobile.umeng.com/ht/api/qb/v1/error/trend?indicator=1&errorClass=1&versions=&startDay=",start_date,"&endDay=",end_date,"&timeUnit=day&relatedId=", device_list[i])
  url2 <- paste0("https://mobile.umeng.com/ht/api/qb/v1/error/trend?indicator=2&errorClass=1&versions=&startDay=",start_date,"&endDay=",end_date,"&timeUnit=day&relatedId=", device_list[i])
  url3 <- paste0("https://mobile.umeng.com/ht/api/qb/v1/error/trend?indicator=3&errorClass=1&versions=&startDay=",start_date,"&endDay=",end_date,"&timeUnit=day&relatedId=", device_list[i])
  url4 <- paste0("https://mobile.umeng.com/ht/api/qb/v1/error/trend?indicator=4&errorClass=1&versions=&startDay=",start_date,"&endDay=",end_date,"&timeUnit=day&relatedId=", device_list[i])
  
  headers<-c('Accept'='application/json, text/plain, */*',  "Mozilla/5.0 (Windows NT 10.0; Win64; x64) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/70.0.3538.102 Safari/537.36",  "Content-Type"="application/json;charset=UTF-8",  "Origin"="https://mobile.umeng.com",  "Referer"="https://mobile.umeng.com/platform/5a9e31a1b27b0a6f070000f9/error_types/trend")
  headers['Cookie']<-Cookies
  
  d <- debugGatherer()
  handle <- getCurlHandle(debugfunction=d$update,followlocation=TRUE,cookiefile="",verbose = TRUE)
  content  <- getForm(url,.opts=list(httpheader=headers),.encoding="utf-8")
  response <- content  %>% fromJSON() 
  content2  <- getForm(url2,.opts=list(httpheader=headers),.encoding="utf-8")
  response2 <- content2  %>% fromJSON() 
  content3  <- getForm(url3,.opts=list(httpheader=headers),.encoding="utf-8")
  response3 <- content3  %>% fromJSON() 
  content4  <- getForm(url4,.opts=list(httpheader=headers),.encoding="utf-8")
  response4 <- content4  %>% fromJSON() 
  
  tmp <- data.frame(device = device_name[i],
                    date = response$data$allData$x,
                    crash_times =  response$data$allData$y,
                    crash_rate = response2$data$allData$y,
                    unique_users = response3$data$allData$y,
                    unique_users_rate = response4$data$allData$y,
                    save_date = Sys.Date()) %>%
    filter(!date %in% date_list)
  
  all <- rbind(all,tmp)
  print(i)
}

####FUN88_android####
selfdefined <- function(indicator){
  url = 'https://mobile.umeng.com/ht/api/qb/v1/error/trend?relatedId=5b0384aaf29d98709600007c'
  
  Payloads=list(
    "endDay"=end_date,
    "errorClass"="2",
    "indicator"= indicator,
    "relatedId"="5b0384aaf29d98709600007c",
    "startDay"=start_date,
    "timeUnit"="day",
    "versions"=""
  )
  
  headers<-c('Accept'='application/json, text/plain, */*',  "User-Agent"="Mozilla/5.0 (Windows NT 10.0; Win64; x64) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/70.0.3538.102 Safari/537.36",  "Content-Type"="application/json;charset=UTF-8",  "Origin"="https://mobile.umeng.com",  "Referer"="https://mobile.umeng.com/platform/5b0384aaf29d98709600007c/error_types/trend")
  headers['Cookie']<-Cookies
  d <- debugGatherer()
  handle <- getCurlHandle(debugfunction=d$update,followlocation=TRUE,cookiefile="",verbose = TRUE)
  content  <- postForm(url,.opts=list(postfields=toJSON(Payloads,auto_unbox=TRUE),httpheader=headers),.encoding="utf-8",curl=handle)
  response <- content  %>% fromJSON() 
  return(response)
}
response <- selfdefined('1')
response2 <- selfdefined('2')
response3 <- selfdefined('3')
response4 <- selfdefined('4')

tmp <- data.frame(device = 'FUN88_android',
                  date = response$data$allData$x,
                  crash_times =  response$data$allData$y,
                  crash_rate = response2$data$allData$y,
                  unique_users = response3$data$allData$y,
                  unique_users_rate = response4$data$allData$y,
                  save_date = Sys.Date()) %>%
  filter(!date %in% date_list)
all <- rbind(all,tmp)
rm(tmp)

#RB88
RB88 <- all %>%
  filter(device == 'RB88_android')
date_list <- as.character(unique(RB88$date))
device_list <- c('25100084ba5f564bb225efb5','450000b2c5655f1fa725efb5')
device_name <- c('RB88_android','RB88_ios')
start_date <- Sys.Date()-15
end_date <- Sys.Date()-1


for (i in 1:length(device_list)) {
  url <- paste0("https://mobile.umeng.com/apps/",device_list[i],"/reports/load_chart_data?start_date=",start_date,"&end_date=",end_date,"&stats=error_count")
  url2 <- paste0("https://mobile.umeng.com/apps/",device_list[i],"/reports/load_chart_data?start_date=",start_date,"&end_date=",end_date,"&stats=error_rate")
  url3 <- paste0("https://mobile.umeng.com/apps/",device_list[i],"/reports/load_chart_data?start_date=",start_date,"&end_date=",end_date,"&stats=error_affect")
  url4 <- paste0("https://mobile.umeng.com/apps/",device_list[i],"/reports/load_chart_data?start_date=",start_date,"&end_date=",end_date,"&stats=error_affect_rate")
  
  headers<-c('Accept'='application/json, text/plain, */*',  "Mozilla/5.0 (Windows NT 10.0; Win64; x64) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/70.0.3538.102 Safari/537.36",  "Content-Type"="application/json;charset=UTF-8",  "Origin"="https://mobile.umeng.com",  "Referer"="https://mobile.umeng.com/platform/5a9e31a1b27b0a6f070000f9/error_types/trend")
  headers['Cookie']<-Cookies
  
  d <- debugGatherer()
  handle <- getCurlHandle(debugfunction=d$update,followlocation=TRUE,cookiefile="",verbose = TRUE)
  content  <- getForm(url,.opts=list(httpheader=headers),.encoding="utf-8")
  response <- content  %>% fromJSON() 
  content2  <- getForm(url2,.opts=list(httpheader=headers),.encoding="utf-8")
  response2 <- content2  %>% fromJSON() 
  content3  <- getForm(url3,.opts=list(httpheader=headers),.encoding="utf-8")
  response3 <- content3  %>% fromJSON() 
  content4  <- getForm(url4,.opts=list(httpheader=headers),.encoding="utf-8")
  response4 <- content4  %>% fromJSON() 
  
  tmp <- data.frame(device = device_name[i],
                    date = as.character(response$dates),
                    crash_times =  response$stats$data[[1]],
                    crash_rate = response2$stats$data[[1]],
                    unique_users = response3$stats$data[[1]],
                    unique_users_rate = response4$stats$data[[1]],
                    save_date = Sys.Date()) %>%
    filter(!date %in% date_list)
  
  all <- rbind(all,tmp)
  print(i)
}
write_csv(all,'/media/sf_data/Umeng_event_/MetaData/crash.csv')


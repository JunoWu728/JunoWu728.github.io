library(shinydashboard)
library(readr)
library(dplyr)
library(plotly)
library(DT)
library(lubridate)

Logged = FALSE;
my_username <- c("Jeffery","Hillary",'Sophy','Drake','test')
my_password <- c("Jeffery1234","Hillary1234","Sophy1234",'Drake1234','test1234')

ui1 <- function(){
  tagList(
    div(id = "login",
        wellPanel(textInput("userName", "Username"),
                  passwordInput("passwd", "Password"),
                  br(),actionButton("Login", "Log in"))),
    tags$style(type="text/css", "#login {font-size:10px;   text-align: left;position:absolute;top: 40%;left: 50%;margin-top: -100px;margin-left: -150px;}")
  )}

ui <- dashboardPage(
  dashboardHeader(title = "Daily Statistics"),
  dashboardSidebar(
    sidebarMenu(
      menuItem("TLC", tabName = "dashboard", icon = icon("dashboard")),
      menuItem("FUN88", tabName = "widgets", icon = icon("th")),
      menuItem("RB88", tabName = "gb88daily", icon = icon("list")),
      menuItem("Weekly(Monthly)Report", tabName = "weekmonth", icon = icon("picture", lib = "glyphicon")),
      menuItem("TLC_TOP10", tabName = "tlctop10", icon = icon("align-left", lib = "glyphicon")),
      menuItem("FUN88_TOP10", tabName = "fun88top10", icon = icon("align-right", lib = "glyphicon")),
      menuItem("TLC_Retention", tabName = "tlcretention", icon = icon("new-window", lib = "glyphicon")),
      menuItem("FUN88_Retention", tabName = "funretention", icon = icon("log-out", lib = "glyphicon")),
      menuItem("TLC_crash", tabName = "tlccrash", icon = icon("remove-sign", lib = "glyphicon")),
      menuItem("FUN88_crash", tabName = "funcrash", icon = icon("ban-circle", lib = "glyphicon")),
      menuItem("RB88_crash", tabName = "rb88crash", icon = icon("minus-square"))
    )
  ),
  dashboardBody(
    tags$head(includeHTML("./google-analytics.html"),
              includeHTML("./hotjar.html"),
              includeHTML("./PIWIK.html")),
    tabItems(
      # First tab content
      tabItem(tabName = "dashboard",
              fluidRow(      
                dateRangeInput('dateRange',label = 'Date range: ',max = Sys.Date(),start = Sys.Date()-7, end = Sys.Date()),
                htmlOutput("page"),
                plotlyOutput("plot1"),
                DTOutput('tbl'),
                downloadButton("downloadData", "Download"))
      ),
      tabItem(tabName = "widgets",
              fluidRow(      
                dateRangeInput('dateRange2',label = 'Date range: ',max = Sys.Date(),start = Sys.Date()-7, end = Sys.Date()),
                plotlyOutput("plot2"),
                DTOutput('tbl2'),
                downloadButton("downloadData2", "Download"))
      ),
      tabItem(tabName = "gb88daily",
              fluidRow(      
                dateRangeInput('rb88dateRange1',label = 'Date range: ',max = Sys.Date(),start = Sys.Date()-7, end = Sys.Date()),
                plotlyOutput("rb88plot1"),
                DTOutput('rb88tbl1'),
                downloadButton("rb88downloadData1", "Download"))
      ),
      tabItem(tabName = "weekmonth",
              fluidRow(      
                selectInput("Report", "Choose a repory:",
                            list(`Weekly` = c("FUN88", "TLC","RB88"),
                                 `Monthly` = c("FUN88(Monthly)", "TLC(Monthly)","RB88(Monthly)"))
                ),
                plotlyOutput("result"),
                plotlyOutput("result1"),
                downloadButton("downloadData15", "Download"))
      ),
      tabItem(tabName = "tlctop10",
              fluidRow(
                verbatimTextOutput("dateText"),
                h3("android"),
                DTOutput('tbl3'),
                h3("ios"),
                DTOutput('tbl4'),
                downloadButton("downloadData4", "Download"))
      ),
      tabItem(tabName = "fun88top10",
              fluidRow(
                verbatimTextOutput("dateText1"),
                h3("android"),
                DTOutput('tbl5'),
                h3("ios"),
                DTOutput('tbl6'),
                downloadButton("downloadData6", "Download"))
      ),
      tabItem(tabName = "tlcretention",
              fluidRow(
                h3("android"),
                DTOutput('tbl7'),
                h3("ios"),
                DTOutput('tbl8'),
                downloadButton("downloadData8", "Download"))
      ),
      tabItem(tabName = "funretention",
              fluidRow(
                h3("android"),
                DTOutput('tbl9'),
                h3("ios"),
                DTOutput('tbl10'),
                downloadButton("downloadData10", "Download"))
      ),
      tabItem(tabName = "tlccrash",
              fluidRow(
                dateRangeInput('dateRange1',label = 'Date range: ',min = '2018-11-11',max = Sys.Date(),start = Sys.Date()-7, end = Sys.Date()),
                h3("android"),
                plotlyOutput("plot11"),
                DTOutput('tbl11'),
                h3("ios"),
                plotlyOutput("plot12"),
                DTOutput('tbl12'),
                downloadButton("downloadData12", "Download"))
      ),
      tabItem(tabName = "funcrash",
              fluidRow(
                dateRangeInput('dateRange3',label = 'Date range: ',min = '2018-11-11',max = Sys.Date(),start = Sys.Date()-7, end = Sys.Date()),
                h3("android"),
                plotlyOutput("plot13"),
                DTOutput('tbl13'),
                h3("ios"),
                plotlyOutput("plot14"),
                DTOutput('tbl14'),
                downloadButton("downloadData14", "Download"))
      ),
      tabItem(tabName = "rb88crash",
              fluidRow(
                dateRangeInput('rb88dateRange3',label = 'Date range: ',min = '2019-02-14',max = Sys.Date(),start = Sys.Date()-7, end = Sys.Date()),
                h3("android"),
                plotlyOutput("rb88plot13"),
                DTOutput('rb88tbl13'),
                h3("ios"),
                plotlyOutput("rb88plot14"),
                DTOutput('rb88tbl14'),
                downloadButton("rb88downloadData14", "Download"))
      )
      
      
      
    )
  )
)

server <- function(input, output,session) {
  USER <- reactiveValues(Logged = Logged)
  
  observe({ 
    if (USER$Logged == FALSE) {
      if (!is.null(input$Login)) {
        if (input$Login > 0) {
          Username <- isolate(input$userName)
          Password <- isolate(input$passwd)
          Id.username <- which(my_username %in% Username)
          Id.password <- which(my_password %in% Password)
          if (length(Id.username) > 0 & length(Id.password) > 0) {
            if (Id.username == Id.password) {
              USER$Logged <- TRUE

            } 
          }
        } 
      }
    }    
  })
 
  observe({
    if (USER$Logged == FALSE) {
      
      output$page <- renderUI({
        div(class="outer",do.call(bootstrapPage,c("",ui1())))
      })
      output$page1 <- renderUI({
        div(class="outer",do.call(bootstrapPage,c("",ui1())))
      })
    }
    if (USER$Logged == TRUE) 
    {
      showModal(modalDialog(
        title = "You have logged in.",
        paste0("Welcome:",input$userName,'. :)'),
        easyClose = TRUE,
        footer = NULL
      ))
      
      df_daily <- read_csv('./Native App Daily Statistics.csv')
      
      output$plot1 <- renderPlotly({
        df <- df_daily %>%
          filter(date >= as.character(input$dateRange[1]) & date <= as.character(input$dateRange[2]))
        
        df_ios <- df[df$device == 'ios',]
        df_android <- df[df$device == 'android',]
        
        ay <- list(
          tickfont = list(color = "black"),
          overlaying = "y",
          side = "right",
          title = "New Installations"
        )
        
        p <- plot_ly(df_ios, x = ~date, y = ~`Active Users of day`, name = 'Active Users of day(ios)', type = 'scatter', mode = 'lines' , line = list(dash = 'line')) %>%
          add_trace(y = df_android$`Active Users of day`, name = 'Active Users of day(android)', mode = 'lines', line = list(dash = 'line')) %>%
          add_trace(y = ~`New Installations`, name = 'New Installations(ios)', mode = 'lines',yaxis = "y2", line = list(dash = 'dash')) %>%
          add_trace(y = df_android$`New Installations`, name = 'New Installations(android)', mode = 'lines',yaxis = "y2", line = list(dash = 'dash')) %>%
          layout(
            title = "TLC", yaxis2 = ay,
            xaxis = list(title="date"),
            yaxis = list(title="Active Users of day")
          )
        p
      })
      
      df_ios <- df_daily[df_daily$device == 'ios',]
      df_android <- df_daily[df_daily$device == 'android',]
      df_com_1 <- left_join(df_ios,df_android,'date')
      output$tbl = renderDT(
        
        df <- df_com_1 %>%
          filter(date >= as.character(input$dateRange[1]) & date <= as.character(input$dateRange[2])) %>%
          rename(`New Installations(ios)` = `New Installations.x`,
                 `Active Users of day(ios)`= `Active Users of day.x`,
                 `New Installations(android)`= `New Installations.y`,
                 `Active Users of day(android)`= `Active Users of day.y`) %>%
          select(date, `New Installations(ios)`, `Active Users of day(ios)`, `New Installations(android)`, `Active Users of day(android)`)
        
        
      )
      
      output$downloadData <- downloadHandler(
        
        
        filename = function() {
          paste("DailyReport.csv", sep = "")
        },
        content = function(file) {
          write.csv(df <- df_com_1 %>%
                      filter(date >= as.character(input$dateRange[1]) & date <= as.character(input$dateRange[2])) %>%
                      rename(`New Installations(ios)` = `New Installations.x`,
                             `Active Users of day(ios)`= `Active Users of day.x`,
                             `New Installations(android)`= `New Installations.y`,
                             `Active Users of day(android)`= `Active Users of day.y`) %>%
                      select(date, `New Installations(ios)`, `Active Users of day(ios)`, `New Installations(android)`, `Active Users of day(android)`)
                    , file, row.names = FALSE)
        }
      )
      
      #FUN88
      df_88 <- read_csv('./Native App Daily Statistics_FUN88.csv')
      
      output$plot2 <- renderPlotly({
        df <- df_88 %>%
          filter(date >= as.character(input$dateRange2[1]) & date <= as.character(input$dateRange2[2]))
        
        df_ios <- df[df$device == 'ios',]
        df_android <- df[df$device == 'android',]
        
        ay <- list(
          tickfont = list(color = "black"),
          overlaying = "y",
          side = "right",
          title = "New Installations"
        )
        
        p <- plot_ly(df_ios, x = ~date, y = ~`Active Users of day`, name = 'Active Users of day(ios)', type = 'scatter', mode = 'lines' , line = list(dash = 'line')) %>%
          add_trace(y = df_android$`Active Users of day`, name = 'Active Users of day(android)', mode = 'lines', line = list(dash = 'line')) %>%
          add_trace(y = ~`New Installations`, name = 'New Installations(ios)', mode = 'lines',yaxis = "y2", line = list(dash = 'dash')) %>%
          add_trace(y = df_android$`New Installations`, name = 'New Installations(android)', mode = 'lines',yaxis = "y2", line = list(dash = 'dash')) %>%
          layout(
            title = "FUN88", yaxis2 = ay,
            xaxis = list(title="date"),
            yaxis = list(title="Active Users of day")
          )
        p
      })
      
      df_ios_88 <- df_88[df_88$device == 'ios',]
      df_android_88 <- df_88[df_88$device == 'android',]
      df_com_88 <- left_join(df_ios_88,df_android_88,'date')
      output$tbl2 = renderDT(
        
        df <- df_com_88 %>%
          filter(date >= as.character(input$dateRange2[1]) & date <= as.character(input$dateRange2[2])) %>%
          rename(`New Installations(ios)` = `New Installations.x`,
                 `Active Users of day(ios)`= `Active Users of day.x`,
                 `New Installations(android)`= `New Installations.y`,
                 `Active Users of day(android)`= `Active Users of day.y`) %>%
          select(date, `New Installations(ios)`, `Active Users of day(ios)`, `New Installations(android)`, `Active Users of day(android)`)
        
        
      )
      
      output$downloadData2 <- downloadHandler(
        
        
        filename = function() {
          paste("DailyReport_FUN88.csv", sep = "")
        },
        content = function(file) {
          write.csv(df <- df_com_88 %>%
                      filter(date >= as.character(input$dateRange2[1]) & date <= as.character(input$dateRange2[2])) %>%
                      rename(`New Installations(ios)` = `New Installations.x`,
                             `Active Users of day(ios)`= `Active Users of day.x`,
                             `New Installations(android)`= `New Installations.y`,
                             `Active Users of day(android)`= `Active Users of day.y`) %>%
                      select(date, `New Installations(ios)`, `Active Users of day(ios)`, `New Installations(android)`, `Active Users of day(android)`)
                    , file, row.names = FALSE)
        }
      )
      
      #RB88_daiily
      df <- read_csv('./Native App Daily Statistics_RB88.csv')
      
      output$rb88plot1 <- renderPlotly({
        df <- df %>%
          filter(date >= as.character(input$rb88dateRange1[1]) & date <= as.character(input$rb88dateRange1[2]))
        
        df_ios <- df[df$device == 'ios',]
        df_android <- df[df$device == 'android',]
        
        ay <- list(
          tickfont = list(color = "black"),
          overlaying = "y",
          side = "right",
          title = "New Installations"
        )
        
        p <- plot_ly(df_ios, x = ~date, y = ~`Active Users of day`, name = 'Active Users of day(ios)', type = 'scatter', mode = 'lines' , line = list(dash = 'line')) %>%
          add_trace(y = df_android$`Active Users of day`, name = 'Active Users of day(android)', mode = 'lines', line = list(dash = 'line')) %>%
          add_trace(y = ~`New Installations`, name = 'New Installations(ios)', mode = 'lines',yaxis = "y2", line = list(dash = 'dash')) %>%
          add_trace(y = df_android$`New Installations`, name = 'New Installations(android)', mode = 'lines',yaxis = "y2", line = list(dash = 'dash')) %>%
          layout(
            title = "RB88", yaxis2 = ay,
            xaxis = list(title="date"),
            yaxis = list(title="Active Users of day")
          )
        p
      })
      
      df_ios <- df[df$device == 'ios',]
      df_android <- df[df$device == 'android',]
      df_com <- left_join(df_ios,df_android,'date')
      
      output$rb88tbl1 = renderDT(
        
        df <- df_com %>%
          filter(date >= as.character(input$rb88dateRange1[1]) & date <= as.character(input$rb88dateRange1[2])) %>%
          rename(`New Installations(ios)` = `New Installations.x`,
                 `Active Users of day(ios)`= `Active Users of day.x`,
                 `New Installations(android)`= `New Installations.y`,
                 `Active Users of day(android)`= `Active Users of day.y`) %>%
          select(date, `New Installations(ios)`, `Active Users of day(ios)`, `New Installations(android)`, `Active Users of day(android)`)
        
        
      )
      
      output$rb88downloadData1 <- downloadHandler(
        
        
        filename = function() {
          paste("DailyReport.csv", sep = "")
        },
        content = function(file) {
          write.csv(df <- df_com %>%
                      filter(date >= as.character(input$rb88dateRange1[1]) & date <= as.character(input$rb88dateRange1[2])) %>%
                      rename(`New Installations(ios)` = `New Installations.x`,
                             `Active Users of day(ios)`= `Active Users of day.x`,
                             `New Installations(android)`= `New Installations.y`,
                             `Active Users of day(android)`= `Active Users of day.y`) %>%
                      select(date, `New Installations(ios)`, `Active Users of day(ios)`, `New Installations(android)`, `Active Users of day(android)`)
                    , file, row.names = FALSE)
        }
      )
      
      
      #TLC_TOP10
      tmp <- read_csv('./1-top10.csv')
      
      tmp1 <- tmp %>%
        group_by(new_event_value_name,device) %>%
        summarise(count = sum(count)) %>%
        group_by(device) %>%
        mutate(percent = round(count/sum(count)*100,2) )
      
      tmp1_android <- tmp1 %>%
        filter(device == 'android') %>%
        arrange(-percent)
      tmp1_android_top10 <- tmp1_android[1:10,c('new_event_value_name','count','percent')] %>%
        rename(Game_name=new_event_value_name)
      
      tmp1_ios <- tmp1 %>%
        filter(device == 'ios') %>%
        arrange(-percent)
      tmp1_ios_top10 <- tmp1_ios[1:10,c('new_event_value_name','count','percent')] %>%
        rename(Game_name=new_event_value_name)
      
      
      
      output$tbl3 = renderDT(
        tmp1_android_top10, options = list(dom = 't')
      )
      output$tbl4 = renderDT(
        tmp1_ios_top10, options = list(dom = 't')
      )
      output$downloadData4 <- downloadHandler(
        
        
        filename = function() {
          paste("DailyReport_FUN88.csv", sep = "")
        },
        content = function(file) {
          write.csv(tmp1
                    , file, row.names = FALSE)
        }
      )
      output$dateText  <- renderText({
        paste0("Date range: ", min(tmp$date),' - ', max(tmp$date))
      })
      
      ####FUN88_TOP10####
      tmp_fun88 <- read_csv('./1-top10_fun88.csv')
      
      tmp1_fun88 <- tmp_fun88 %>%
        group_by(new_event_value_name,device) %>%
        summarise(count = sum(count)) %>%
        group_by(device) %>%
        mutate(percent = round(count/sum(count)*100,2) )
      
      tmp1_android_fun88 <- tmp1_fun88 %>%
        filter(device == 'android') %>%
        arrange(-percent)
      tmp1_android_top10_fun88 <- tmp1_android_fun88[1:10,c('new_event_value_name','count','percent')] %>%
        rename(Game_name=new_event_value_name)
      
      tmp1_ios_fun88 <- tmp1_fun88 %>%
        filter(device == 'ios') %>%
        arrange(-percent)
      tmp1_ios_top10_fun88 <- tmp1_ios_fun88[1:10,c('new_event_value_name','count','percent')] %>%
        rename(Game_name=new_event_value_name)
      
      
      
      output$tbl5 = renderDT(
        tmp1_android_top10_fun88, options = list(dom = 't')
      )
      output$tbl6 = renderDT(
        tmp1_ios_top10_fun88, options = list(dom = 't')
      )
      output$downloadData6 <- downloadHandler(
        
        
        filename = function() {
          paste("DailyReport_FUN88.csv", sep = "")
        },
        content = function(file) {
          write.csv(tmp1_fun88
                    , file, row.names = FALSE)
        }
      )
      output$dateText1  <- renderText({
        paste0("Date range: ", min(tmp_fun88$date),' - ', max(tmp_fun88$date))
      })
      
      ####retension_TLC####
      retention <- function(device_name) {
        tmpp <- read_csv('./2-Newuserweeklyretention.csv')
        
        tmpp1 <- tmpp %>%
          filter(device == device_name)
        tmpp1$Retention_1wk <- sapply(strsplit(tmpp1$retentionRate, ","), "[[", 1)
        tmpp1$Retention_1wk <- gsub('\\[','',tmpp1$Retention_1wk)
        tmpp1$Retention_1wk <- gsub('\\]','',tmpp1$Retention_1wk)
        
        tmpp1$Retention_4wk <- c(sapply(strsplit(tmpp1$retentionRate[(1:(nrow(tmpp1)-3))], ","), "[[", 4),rep(NA,3))
        tmpp1$Retention_4wk <- gsub('\\]','',tmpp1$Retention_4wk)
        
        tmpp1 <- tmpp1[,c('date','totalInstallUser','Retention_1wk','Retention_4wk')] %>%
          rename(NewUsers=totalInstallUser)
        
        return(tmpp1)
      }
      min_1wk <- retention('android') %>%
        filter(Retention_1wk == min(Retention_1wk))
      max_1wk <- retention('android') %>%
        filter(Retention_1wk == max(Retention_1wk))
      min_4wk <- retention('android') %>%
        filter(Retention_4wk == min(Retention_4wk,na.rm=T))
      max_4wk <- retention('android') %>%
        filter(Retention_4wk == max(Retention_4wk,na.rm=T))
      
      output$tbl7 = renderDT(
        datatable(retention('android'), options = list(dom = 't',pageLength = 30))  %>%
          formatStyle(
            'Retention_1wk',
            color = styleInterval(c(as.numeric(min_1wk$Retention_1wk)[1]+0.1, as.numeric(max_1wk$Retention_1wk)[1])-0.1, c('red', 'black', 'blue'))
          ) %>%
          formatStyle(
            'Retention_4wk',
            color = styleInterval(c(as.numeric(min_4wk$Retention_4wk)[1]+0.1, as.numeric(max_4wk$Retention_4wk)[1])-0.1, c('red', 'black', 'blue'))
          )
      )
      
      min_1wk_ios <- retention('ios') %>%
        filter(Retention_1wk == min(Retention_1wk))
      max_1wk_ios <- retention('ios') %>%
        filter(Retention_1wk == max(Retention_1wk))
      min_4wk_ios <- retention('ios') %>%
        filter(Retention_4wk == min(Retention_4wk,na.rm=T))
      max_4wk_ios <- retention('ios') %>%
        filter(Retention_4wk == max(Retention_4wk,na.rm=T))
      
      output$tbl8 = renderDT(
        datatable(retention('ios'), options = list(dom = 't',
                                         pageLength = 30)) %>%
          formatStyle(
            'Retention_1wk',
            color = styleInterval(c(as.numeric(min_1wk_ios$Retention_1wk)[1]+0.1, as.numeric(max_1wk_ios$Retention_1wk)[1])-0.1, c('red', 'black', 'blue'))
          ) %>%
          formatStyle(
            'Retention_4wk',
            color = styleInterval(c(as.numeric(min_4wk_ios$Retention_4wk)[1]+0.1, as.numeric(max_4wk_ios$Retention_4wk)[1])-0.1, c('red', 'black', 'blue'))
          )
      )
      
      output$downloadData8 <- downloadHandler(
        filename = function() {
          paste("DailyReport_FUN88.csv", sep = "")
        },
        content = function(file) {
          write.csv(rbind(retention('android'),retention('ios'))
                    , file, row.names = FALSE)
        }
      )
      
      ####retension_FUN88####
      retention_fun88 <- function(device_name) {
        tmpp <- read_csv('./2-Newuserweeklyretention_fun88.csv') 
        
        tmpp1 <- tmpp %>%
          filter(device == device_name)
        tmpp1$Retention_1wk <- sapply(strsplit(tmpp1$retentionRate, ","), "[[", 1)
        tmpp1$Retention_1wk <- gsub('\\[','',tmpp1$Retention_1wk)
        tmpp1$Retention_1wk <- gsub('\\]','',tmpp1$Retention_1wk)
        
        tmpp1$Retention_4wk <- c(sapply(strsplit(tmpp1$retentionRate[(1:(nrow(tmpp1)-3))], ","), "[[", 4),rep(NA,3))
        tmpp1$Retention_4wk <- gsub('\\]','',tmpp1$Retention_4wk)
        
        tmpp1 <- tmpp1[,c('date','totalInstallUser','Retention_1wk','Retention_4wk')] %>%
          rename(NewUsers=totalInstallUser)
        
        return(tmpp1)
      }
      
      min_1wk_fun88 <- retention_fun88('android') %>%
        filter(date > '2018-10-21') %>%
        filter(Retention_1wk == min(Retention_1wk))
      max_1wk_fun88 <- retention_fun88('android') %>%
        filter(date > '2018-10-21') %>%
        filter(Retention_1wk == max(Retention_1wk))
      min_4wk_fun88 <- retention_fun88('android') %>%
        filter(date > '2018-10-21') %>%
        filter(Retention_4wk == min(Retention_4wk,na.rm=T))
      max_4wk_fun88 <- retention_fun88('android') %>%
        filter(date > '2018-10-21') %>%
        filter(Retention_4wk == max(Retention_4wk,na.rm=T))
      
      output$tbl9 = renderDT(
        datatable(retention_fun88('android') %>%
                  filter(date > '2018-10-21') , options = list(dom = 't',pageLength = 30)) %>%
          formatStyle(
            'Retention_1wk',
            color = styleInterval(c(as.numeric(min_1wk_fun88$Retention_1wk)[1]+0.1, as.numeric(max_1wk_fun88$Retention_1wk)[1])-0.1, c('red', 'black', 'blue'))
          ) %>%
          formatStyle(
            'Retention_4wk',
            color = styleInterval(c(as.numeric(min_4wk_fun88$Retention_4wk)[1]+0.1, as.numeric(max_4wk_fun88$Retention_4wk)[1])-0.1, c('red', 'black', 'blue'))
          )
      )
      
      min_1wk_ios_fun88 <- retention_fun88('ios') %>%
        filter(date > '2018-10-21') %>%
        filter(Retention_1wk == min(Retention_1wk))
      max_1wk_ios_fun88 <- retention_fun88('ios') %>%
        filter(date > '2018-10-21') %>%
        filter(Retention_1wk == max(Retention_1wk))
      min_4wk_ios_fun88 <- retention_fun88('ios') %>%
        filter(date > '2018-10-21') %>%
        filter(Retention_4wk == min(Retention_4wk,na.rm=T))
      max_4wk_ios_fun88 <- retention_fun88('ios') %>%
        filter(date > '2018-10-21') %>%
        filter(Retention_4wk == max(Retention_4wk,na.rm=T))
      
      output$tbl10 = renderDT(
        datatable(retention_fun88('ios') %>%
                    filter(date > '2018-10-21') , options = list(dom = 't',pageLength = 30)) %>%
          formatStyle(
            'Retention_1wk',
            color = styleInterval(c(as.numeric(min_1wk_ios_fun88$Retention_1wk)[1]+0.1, as.numeric(max_1wk_ios_fun88$Retention_1wk)[1])-0.1, c('red', 'black', 'blue'))
          ) %>%
          formatStyle(
            'Retention_4wk',
            color = styleInterval(c(as.numeric(min_4wk_ios_fun88$Retention_4wk)[1]+0.1, as.numeric(max_4wk_ios_fun88$Retention_4wk)[1])-0.1, c('red', 'black', 'blue'))
          )
      )
      
      output$downloadData10 <- downloadHandler(
        filename = function() {
          paste("DailyReport_FUN88.csv", sep = "")
        },
        content = function(file) {
          write.csv(rbind(retention_fun88('android'),retention_fun88('ios'))
                    , file, row.names = FALSE)
        }
      )
      
      ####Crash rate_TLC_tlccrash####
      crash <- read_csv('./crash.csv') %>%
        mutate(unique_users_rate = round(unique_users_rate,2))
      
      output$tbl11 = renderDT(
        crash %>%
          filter(device == 'TLC_android',date >= as.character(input$dateRange1[1]) & date <= as.character(input$dateRange1[2])) %>%
          select(date,crash_times,unique_users,unique_users_rate)
        , options = list(dom = 't',pageLength = 30)
      )
      output$tbl12 = renderDT(
        crash %>%
          filter(device == 'TLC_ios',date >= as.character(input$dateRange1[1]) & date <= as.character(input$dateRange1[2])) %>%
          select(date,crash_times,unique_users,unique_users_rate)
        , options = list(dom = 't',pageLength = 30)
      )
      
      output$plot11 <- renderPlotly({
        crash_tlc_android <- crash %>%
          filter(device == 'TLC_android',date >= as.character(input$dateRange1[1]) & date <= as.character(input$dateRange1[2]))
        

        ay <- list(
          tickfont = list(color = "black"),
          overlaying = "y",
          side = "right",
          title = "unique_users_rate(%)"
        )
        
        p <- plot_ly(crash_tlc_android, x = ~date, y = ~crash_times, name = 'crash_times', type = 'scatter', mode = 'lines' ) %>%
          add_trace(y = ~unique_users, name = 'unique_users', mode = 'lines') %>%
          add_trace(y = ~unique_users_rate, name = 'unique_users_rate', type = 'scatter', mode = 'lines',yaxis = "y2" , line = list(dash = 'dash')) %>%
          layout(
            title = "TLC_android", yaxis2 = ay,
            xaxis = list(title="date"),
            yaxis = list(title="crash_times")
          )
        p
      })
      output$plot12 <- renderPlotly({
        crash_tlc_ios <- crash %>%
          filter(device == 'TLC_ios',date >= as.character(input$dateRange1[1]) & date <= as.character(input$dateRange1[2]))
        
        
        ay <- list(
          tickfont = list(color = "black"),
          overlaying = "y",
          side = "right",
          title = "unique_users_rate(%)"
        )
        
        p <- plot_ly(crash_tlc_ios, x = ~date, y = ~crash_times, name = 'crash_times', type = 'scatter', mode = 'lines' ) %>%
          add_trace(y = ~unique_users, name = 'unique_users', mode = 'lines') %>%
          add_trace(y = ~unique_users_rate, name = 'unique_users_rate', type = 'scatter', mode = 'lines',yaxis = "y2" , line = list(dash = 'dash')) %>%
          layout(
            title = "TLC_ios", yaxis2 = ay,
            xaxis = list(title="date"),
            yaxis = list(title="crash_times")
          )
        p
      })
      output$downloadData12 <- downloadHandler(
        filename = function() {
          paste("TLC_crash.csv", sep = "")
        },
        content = function(file) {
          write.csv(crash[grepl('TLC',crash$device),], file, row.names = FALSE)
        }
      )
      
      ####Crash rate_RB88_funcrash####

      output$rb88tbl13 = renderDT(
        crash %>%
          filter(device == 'RB88_android',date >= as.character(input$rb88dateRange3[1]) & date <= as.character(input$rb88dateRange3[2])) %>%
          select(date,crash_times,unique_users,unique_users_rate)
        , options = list(dom = 't',pageLength = 30)
      )
      output$rb88tbl14 = renderDT(
        crash %>%
          filter(device == 'RB88_ios',date >= as.character(input$rb88dateRange3[1]) & date <= as.character(input$rb88dateRange3[2])) %>%
          select(date,crash_times,unique_users,unique_users_rate)
        , options = list(dom = 't',pageLength = 30)
      )
      
      output$rb88plot13 <- renderPlotly({
        crash_fun_android <- crash %>%
          filter(device == 'RB88_android',date >= as.character(input$rb88dateRange3[1]) & date <= as.character(input$rb88dateRange3[2]))
        
        
        ay <- list(
          tickfont = list(color = "black"),
          overlaying = "y",
          side = "right",
          title = "unique_users_rate(%)"
        )
        
        p <- plot_ly(crash_fun_android, x = ~date, y = ~crash_times, name = 'crash_times', type = 'scatter', mode = 'lines' ) %>%
          add_trace(y = ~unique_users, name = 'unique_users', mode = 'lines') %>%
          add_trace(y = ~unique_users_rate, name = 'unique_users_rate', type = 'scatter', mode = 'lines',yaxis = "y2" , line = list(dash = 'dash')) %>%
          layout(
            title = "RB88_android", yaxis2 = ay,
            xaxis = list(title="date"),
            yaxis = list(title="crash_times")
          )
        p
      })
      output$rb88plot14 <- renderPlotly({
        crash_fun_ios <- crash %>%
          filter(device == 'RB88_ios',date >= as.character(input$rb88dateRange3[1]) & date <= as.character(input$rb88dateRange3[2]))
        
        
        ay <- list(
          tickfont = list(color = "black"),
          overlaying = "y",
          side = "right",
          title = "unique_users_rate(%)"
        )
        p <- plot_ly(crash_fun_ios, x = ~date, y = ~crash_times, name = 'crash_times', type = 'scatter', mode = 'lines' ) %>%
          add_trace(y = ~unique_users, name = 'unique_users', mode = 'lines') %>%
          add_trace(y = ~unique_users_rate, name = 'unique_users_rate', type = 'scatter', mode = 'lines',yaxis = "y2" , line = list(dash = 'dash')) %>%
          layout(
            title = "RB88_ios", yaxis2 = ay,
            xaxis = list(title="date"),
            yaxis = list(title="crash_times")
          )
        p
      })
      output$rb88downloadData14 <- downloadHandler(
        filename = function() {
          paste("RB88_crash.csv", sep = "")
        },
        content = function(file) {
          write.csv(crash[grepl('RB88',crash$device),], file, row.names = FALSE)
        }
      )
      
      ####Crash rate_FUN88_funcrash####
      
      output$tbl13 = renderDT(
        crash %>%
          filter(device == 'FUN88_android',date >= as.character(input$dateRange3[1]) & date <= as.character(input$dateRange3[2])) %>%
          select(date,crash_times,unique_users,unique_users_rate)
        , options = list(dom = 't',pageLength = 30)
      )
      output$tbl14 = renderDT(
        crash %>%
          filter(device == 'FUN88_ios',date >= as.character(input$dateRange3[1]) & date <= as.character(input$dateRange3[2])) %>%
          select(date,crash_times,unique_users,unique_users_rate)
        , options = list(dom = 't',pageLength = 30)
      )
      
      output$plot13 <- renderPlotly({
        crash_fun_android <- crash %>%
          filter(device == 'FUN88_android',date >= as.character(input$dateRange3[1]) & date <= as.character(input$dateRange3[2]))
        
        
        ay <- list(
          tickfont = list(color = "black"),
          overlaying = "y",
          side = "right",
          title = "unique_users_rate(%)"
        )
        
        p <- plot_ly(crash_fun_android, x = ~date, y = ~crash_times, name = 'crash_times', type = 'scatter', mode = 'lines' ) %>%
          add_trace(y = ~unique_users, name = 'unique_users', mode = 'lines') %>%
          add_trace(y = ~unique_users_rate, name = 'unique_users_rate', type = 'scatter', mode = 'lines',yaxis = "y2" , line = list(dash = 'dash')) %>%
          layout(
            title = "FUN88_android", yaxis2 = ay,
            xaxis = list(title="date"),
            yaxis = list(title="crash_times")
          )
        p
      })
      output$plot14 <- renderPlotly({
        crash_fun_ios <- crash %>%
          filter(device == 'FUN88_ios',date >= as.character(input$dateRange3[1]) & date <= as.character(input$dateRange3[2]))
        
        
        ay <- list(
          tickfont = list(color = "black"),
          overlaying = "y",
          side = "right",
          title = "unique_users_rate(%)"
        )
        p <- plot_ly(crash_fun_ios, x = ~date, y = ~crash_times, name = 'crash_times', type = 'scatter', mode = 'lines' ) %>%
          add_trace(y = ~unique_users, name = 'unique_users', mode = 'lines') %>%
          add_trace(y = ~unique_users_rate, name = 'unique_users_rate', type = 'scatter', mode = 'lines',yaxis = "y2" , line = list(dash = 'dash')) %>%
          layout(
            title = "FUN88_ios", yaxis2 = ay,
            xaxis = list(title="date"),
            yaxis = list(title="crash_times")
          )
        p
      })
      output$downloadData14 <- downloadHandler(
        filename = function() {
          paste("FUN88_crash.csv", sep = "")
        },
        content = function(file) {
          write.csv(crash[grepl('FUN88',crash$device),], file, row.names = FALSE)
        }
      )
      ####MonthlyWeeklyReport####
      MonthlyReport <- function(monthly,daily){
        tmp1 <- read_csv(monthly) %>% 
          rename('month'=date)
        tmp11 <- read_csv(daily) %>% 
          group_by(device,month=floor_date(date, "month")) %>%
          summarize(NewInstallations=sum(`New Installations`)) %>%
          mutate(TotalInstallations=cumsum(NewInstallations))
        
        tmp2 <- left_join(tmp1,tmp11) %>%
          select(month,device,NewInstallations,TotalInstallations,activeUser)
        return(tmp2)
      }
      
      WeeklyReport <- function(weekly,daily){
        tmp1 <- read_csv(weekly)
        tmp11 <- read_csv(daily) %>%
          filter(date >= min(tmp1$date)) %>%
          group_by(device) %>%
          mutate(weeks= as.integer((0:(n()-1))/7) ) %>%
          group_by(device,weeks) %>%
          summarize(date = min(date),
                    NewInstallations=sum(`New Installations`)) %>%
          mutate(TotalInstallations=cumsum(NewInstallations))
        
        tmp2 <- left_join(tmp1,tmp11) %>%
          select(date,DateEnd,device,NewInstallations,TotalInstallations,activeUser) %>%
          rename(DateStart = date)
        return(tmp2)
      }
      
      
      monthly_tlc <- './Native App Monthly Statistics.csv'
      weekly_tlc <- './Native App Weekly Statistics.csv'
      daily_tlc <- './Native App Daily Statistics.csv'
      monthly_fun88 <- './Native App Monthly Statistics_FUN88.csv'
      weekly_fun88 <- './Native App Weekly Statistics_FUN88.csv'
      daily_fun88 <- './Native App Daily Statistics_FUN88.csv'
      monthly_rb88 <- './Native App Monthly Statistics_RB88.csv'
      weekly_rb88 <- './Native App Weekly Statistics_RB88.csv'
      daily_rb88 <- './Native App Daily Statistics_RB88.csv'
      
      output$result <- renderPlotly({
        if(input$Report=='FUN88(Monthly)'){
          df1 <- MonthlyReport(monthly_fun88,daily_fun88) %>%
            filter(device == 'android' & NewInstallations > 0) %>%
            mutate(month = as.character(month))
          plot_ly(df1, x = ~month, y = ~NewInstallations, type = 'bar', 
                  text = ~NewInstallations, textposition = 'auto', name = 'NewInstallations') %>%
            add_trace(y = ~TotalInstallations, 
                      text = ~TotalInstallations, textposition = 'auto', name = 'TotalInstallations') %>%
            add_trace(y = ~activeUser, 
                      text = ~activeUser, textposition = 'auto', name = 'activeUser') %>%
            layout(yaxis = list(title = 'Unique_User'), barmode = 'group',title = "FUN88_Monthly_android")
        } else if (input$Report=='TLC(Monthly)'){
          df1 <- MonthlyReport(monthly_tlc,daily_tlc) %>%
            filter(device == 'android' & NewInstallations > 0) %>%
            mutate(month = as.character(month))
          plot_ly(df1, x = ~month, y = ~NewInstallations, type = 'bar', 
                  text = ~NewInstallations, textposition = 'auto', name = 'NewInstallations') %>%
            add_trace(y = ~TotalInstallations, 
                      text = ~TotalInstallations, textposition = 'auto', name = 'TotalInstallations') %>%
            add_trace(y = ~activeUser, 
                      text = ~activeUser, textposition = 'auto', name = 'activeUser') %>%
            layout(yaxis = list(title = 'Unique_User'), barmode = 'group',title = "TLC_Monthly_android")
        } else if (input$Report=='RB88(Monthly)'){
          df1 <- MonthlyReport(monthly_rb88,daily_rb88) %>%
            filter(device == 'android' & NewInstallations > 0) %>%
            mutate(month = as.character(month))
          plot_ly(df1, x = ~month, y = ~NewInstallations, type = 'bar', 
                  text = ~NewInstallations, textposition = 'auto', name = 'NewInstallations') %>%
            add_trace(y = ~TotalInstallations, 
                      text = ~TotalInstallations, textposition = 'auto', name = 'TotalInstallations') %>%
            add_trace(y = ~activeUser, 
                      text = ~activeUser, textposition = 'auto', name = 'activeUser') %>%
            layout(yaxis = list(title = 'Unique_User'), barmode = 'group',title = "RB88_Monthly_android")
        } else if (input$Report=='FUN88'){
          df1 <- WeeklyReport(weekly_fun88,daily_fun88) %>%
            filter(device == 'android' & NewInstallations > 0) %>%
            mutate(DateStart = as.character(DateStart))
          plot_ly(df1, x = ~DateStart, y = ~NewInstallations, type = 'bar', 
                  text = ~NewInstallations, textposition = 'auto', name = 'NewInstallations') %>%
            add_trace(y = ~TotalInstallations, 
                      text = ~TotalInstallations, textposition = 'auto', name = 'TotalInstallations') %>%
            add_trace(y = ~activeUser, 
                      text = ~activeUser, textposition = 'auto', name = 'activeUser') %>%
            layout(yaxis = list(title = 'Unique_User'), barmode = 'group',title = "FUN88_Weekly_android")
        } else if (input$Report=='TLC'){
          df1 <- WeeklyReport(weekly_tlc,daily_tlc) %>%
            filter(device == 'android' & NewInstallations > 0) %>%
            mutate(DateStart = as.character(DateStart))
          plot_ly(df1, x = ~DateStart, y = ~NewInstallations, type = 'bar', 
                  text = ~NewInstallations, textposition = 'auto', name = 'NewInstallations') %>%
            add_trace(y = ~TotalInstallations, 
                      text = ~TotalInstallations, textposition = 'auto', name = 'TotalInstallations') %>%
            add_trace(y = ~activeUser, 
                      text = ~activeUser, textposition = 'auto', name = 'activeUser') %>%
            layout(yaxis = list(title = 'Unique_User'), barmode = 'group',title = "TLC_Weekly_android")
        } else if (input$Report=='RB88'){
          df1 <- WeeklyReport(weekly_rb88,daily_rb88) %>%
            filter(device == 'android' & NewInstallations > 0) %>%
            mutate(DateStart = as.character(DateStart))
          plot_ly(df1, x = ~DateStart, y = ~NewInstallations, type = 'bar', 
                  text = ~NewInstallations, textposition = 'auto', name = 'NewInstallations') %>%
            add_trace(y = ~TotalInstallations, 
                      text = ~TotalInstallations, textposition = 'auto', name = 'TotalInstallations') %>%
            add_trace(y = ~activeUser, 
                      text = ~activeUser, textposition = 'auto', name = 'activeUser') %>%
            layout(yaxis = list(title = 'Unique_User'), barmode = 'group',title = "RB88_Weekly_android")
        }
        
      })
      output$result1 <- renderPlotly({
        if(input$Report=='FUN88(Monthly)'){
          df1 <- MonthlyReport(monthly_fun88,daily_fun88) %>%
            filter(device == 'ios' & NewInstallations > 0) %>%
            mutate(month = as.character(month))
          plot_ly(df1, x = ~month, y = ~NewInstallations, type = 'bar', 
                  text = ~NewInstallations, textposition = 'auto', name = 'NewInstallations') %>%
            add_trace(y = ~TotalInstallations, 
                      text = ~TotalInstallations, textposition = 'auto', name = 'TotalInstallations') %>%
            add_trace(y = ~activeUser, 
                      text = ~activeUser, textposition = 'auto', name = 'activeUser') %>%
            layout(yaxis = list(title = 'Unique_User'), barmode = 'group',title = "FUN88_Monthly_iOS")
          
        } else if(input$Report=='TLC(Monthly)'){
          df1 <- MonthlyReport(monthly_tlc,daily_tlc) %>%
            filter(device == 'ios' & NewInstallations > 0) %>%
            mutate(month = as.character(month))
          plot_ly(df1, x = ~month, y = ~NewInstallations, type = 'bar', 
                  text = ~NewInstallations, textposition = 'auto', name = 'NewInstallations') %>%
            add_trace(y = ~TotalInstallations, 
                      text = ~TotalInstallations, textposition = 'auto', name = 'TotalInstallations') %>%
            add_trace(y = ~activeUser, 
                      text = ~activeUser, textposition = 'auto', name = 'activeUser') %>%
            layout(yaxis = list(title = 'Unique_User'), barmode = 'group',title = "TLC_Monthly_iOS")
        } else if(input$Report=='RB88(Monthly)'){
          df1 <- MonthlyReport(monthly_rb88,daily_rb88) %>%
            filter(device == 'ios' & NewInstallations > 0) %>%
            mutate(month = as.character(month))
          plot_ly(df1, x = ~month, y = ~NewInstallations, type = 'bar', 
                  text = ~NewInstallations, textposition = 'auto', name = 'NewInstallations') %>%
            add_trace(y = ~TotalInstallations, 
                      text = ~TotalInstallations, textposition = 'auto', name = 'TotalInstallations') %>%
            add_trace(y = ~activeUser, 
                      text = ~activeUser, textposition = 'auto', name = 'activeUser') %>%
            layout(yaxis = list(title = 'Unique_User'), barmode = 'group',title = "RB88_Monthly_iOS")
        } else if(input$Report=='TLC'){
          df1 <- WeeklyReport(weekly_tlc,daily_tlc) %>%
            filter(device == 'ios' & NewInstallations > 0) %>%
            mutate(DateStart = as.character(DateStart))
          plot_ly(df1, x = ~DateStart, y = ~NewInstallations, type = 'bar', 
                  text = ~NewInstallations, textposition = 'auto', name = 'NewInstallations') %>%
            add_trace(y = ~TotalInstallations, 
                      text = ~TotalInstallations, textposition = 'auto', name = 'TotalInstallations') %>%
            add_trace(y = ~activeUser, 
                      text = ~activeUser, textposition = 'auto', name = 'activeUser') %>%
            layout(yaxis = list(title = 'Unique_User'), barmode = 'group',title = "TLC_Weekly_iOS")
        } else if(input$Report=='FUN88'){
          df1 <- WeeklyReport(weekly_fun88,daily_fun88) %>%
            filter(device == 'ios' & NewInstallations > 0) %>%
            mutate(DateStart = as.character(DateStart))
          plot_ly(df1, x = ~DateStart, y = ~NewInstallations, type = 'bar', 
                  text = ~NewInstallations, textposition = 'auto', name = 'NewInstallations') %>%
            add_trace(y = ~TotalInstallations, 
                      text = ~TotalInstallations, textposition = 'auto', name = 'TotalInstallations') %>%
            add_trace(y = ~activeUser, 
                      text = ~activeUser, textposition = 'auto', name = 'activeUser') %>%
            layout(yaxis = list(title = 'Unique_User'), barmode = 'group',title = "FUN88_Weekly_iOS")
        } else if(input$Report=='RB88'){
          df1 <- WeeklyReport(weekly_rb88,daily_rb88) %>%
            filter(device == 'ios' & NewInstallations > 0) %>%
            mutate(DateStart = as.character(DateStart))
          plot_ly(df1, x = ~DateStart, y = ~NewInstallations, type = 'bar', 
                  text = ~NewInstallations, textposition = 'auto', name = 'NewInstallations') %>%
            add_trace(y = ~TotalInstallations, 
                      text = ~TotalInstallations, textposition = 'auto', name = 'TotalInstallations') %>%
            add_trace(y = ~activeUser, 
                      text = ~activeUser, textposition = 'auto', name = 'activeUser') %>%
            layout(yaxis = list(title = 'Unique_User'), barmode = 'group',title = "RB88_Weekly_iOS")
        } 
      })
      
      datasetInput <- reactive({
        if(input$Report=='FUN88(Monthly)') {
          MonthlyReport(monthly_fun88,monthly_fun88)
        } else if (input$Report=='TLC(Monthly)') {
          MonthlyReport(monthly_tlc,daily_tlc)
        } else if (input$Report=='TLC') {
          WeeklyReport(weekly_tlc,weekly_tlc)
        } else if (input$Report=='FUN88') {
          WeeklyReport(weekly_fun88,weekly_fun88)
        } 
      })
      
      output$downloadData15 <- downloadHandler (
        filename = function() {
          paste(input$Report,".csv", sep = "")
        },
        content = function(file) {
          write.csv(datasetInput()
                    , file, row.names = FALSE)
        }
      )
      
      
      
      
      
      
    }
  })
  
  
  
  
}

shinyApp(ui, server)